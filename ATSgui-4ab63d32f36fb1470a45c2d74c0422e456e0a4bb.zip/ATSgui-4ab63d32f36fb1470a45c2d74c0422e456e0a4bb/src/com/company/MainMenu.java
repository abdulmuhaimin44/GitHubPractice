package com.company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu {
    private JButton logoutButton;
    private JButton recordSaleButton;
    private JButton showIndividualReportButton;
    private JButton viewBlanksButton;
    private JButton viewCustomersButton;
    public JPanel panel;

    public MainMenu(JFrame frame) {
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.login);
                frame.setVisible(true);
            }
        });
        recordSaleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.recordSale);
                frame.setVisible(true);
            }
        });
        viewBlanksButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewBlanks);
                frame.setVisible(true);
            }
        });
        viewCustomersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewCustomers);
                frame.setVisible(true);
            }
        });
    }
}
