package com.company.customer;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DeleteCustomer {
    public JPanel panel;
    private JButton saveButton;
    private JButton cancelButton;
    private JComboBox comboBox1;

    public DeleteCustomer(JFrame frame) {
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewCustomers);
                frame.setVisible(true);
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewCustomers);
                frame.setVisible(true);
            }
        });
    }
}
