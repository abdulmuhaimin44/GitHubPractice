package com.company.customer;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewCustomers {
    public JPanel panel;
    private JTable table1;
    private JButton newCustomerButton;
    private JButton deleteCustomerButton;
    private JButton mainMenuButton;
    private JButton editCustomerDetailsButton;

    public ViewCustomers(JFrame frame) {
        mainMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.mainMenu);
                frame.setVisible(true);
            }
        });
        newCustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.createCustomer);
                frame.setVisible(true);
            }
        });
        deleteCustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.deleteCustomer);
                frame.setVisible(true);
            }
        });
        editCustomerDetailsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.editCustomer);
                frame.setVisible(true);
            }
        });
    }
}
