package com.company.customer;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditCustomer {
    private JButton cancelButton;
    private JButton saveButton;
    private JComboBox comboBox1;
    private JTextField textField1;
    private JTextField textField2;
    private JRadioButton fixedRadioButton;
    private JRadioButton flexibleRadioButton;
    public JPanel panel;

    public EditCustomer(JFrame frame) {
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewCustomers);
                frame.setVisible(true);
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewCustomers);
                frame.setVisible(true);
            }
        });
    }
}
