package com.company.customer;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreateCustomer {
    private JTextField textField1;
    private JTextField textField2;
    private JButton saveButton;
    private JButton closeButton;
    public JPanel panel;

    public CreateCustomer(JFrame frame) {
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewCustomers);
                frame.setVisible(true);
            }
        });
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewCustomers);
                frame.setVisible(true);
            }
        });
    }
}
