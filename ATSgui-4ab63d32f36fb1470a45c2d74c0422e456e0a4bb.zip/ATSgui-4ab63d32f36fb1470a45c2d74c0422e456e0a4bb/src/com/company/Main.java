package com.company;

import com.company.blank.*;
import com.company.customer.CreateCustomer;
import com.company.customer.DeleteCustomer;
import com.company.customer.EditCustomer;
import com.company.customer.ViewCustomers;
import com.company.report.ShowReports;

import javax.net.ssl.SNIHostName;
import javax.swing.*;
import java.awt.*;

public class Main {
    //Advisor
    public static JPanel mainMenu;
    public static JPanel login;
    public static JPanel recordSale;
    public static JPanel viewBlanks;
    public static JPanel returnBlank;
    public static JPanel lostStolenBlank;
    public static JPanel viewCustomers;
    public static JPanel editCustomer;
    public static JPanel createCustomer;
    public static JPanel deleteCustomer;

    //Office Manager
    public static JPanel officeMenu;
    public static JPanel setCommission;
    public static JPanel assignBlank;
    public static JPanel showReports;

    //Admin
    //TODO
    public static void main(String[] args) {
        JFrame frame = new JFrame("ATS");

        //Advisor
        mainMenu=new MainMenu(frame).panel;
        login=new LoginForm(frame).panel;
        recordSale=new RecordSale(frame).panel;
        viewBlanks=new ViewBlanks(frame).panel;
        returnBlank=new ReturnBlank(frame).panel;
        lostStolenBlank=new LostStolenBlank(frame).panel;
        viewCustomers=new ViewCustomers(frame).panel;
        editCustomer= new EditCustomer(frame).panel;
        createCustomer= new CreateCustomer(frame).panel;
        deleteCustomer=new DeleteCustomer(frame).panel;
        //TODO: INDIVIDUAL REPORT

        //Office Manager
        officeMenu=new OfficeMenu(frame).panel;
        setCommission=new SetCommission(frame).panel;
        assignBlank=new AssignBlank(frame).panel;
        showReports=new ShowReports(frame).panel;
        //TODO: GLOBAL REPORT
        //TODO: TURNOVER REPORT

        frame.add(login, BorderLayout.CENTER);
        frame.setSize(800,480);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
