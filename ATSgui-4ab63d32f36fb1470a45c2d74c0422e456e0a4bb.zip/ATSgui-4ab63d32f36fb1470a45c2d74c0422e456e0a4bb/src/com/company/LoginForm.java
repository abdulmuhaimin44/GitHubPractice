package com.company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginForm {
    private JPasswordField password;
    public JPanel panel;
    private JButton loginButton;
    private JTextField textField1;

    public LoginForm(JFrame frame) {
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.officeMenu);
                frame.setVisible(true);
            }
        });
    }
}
