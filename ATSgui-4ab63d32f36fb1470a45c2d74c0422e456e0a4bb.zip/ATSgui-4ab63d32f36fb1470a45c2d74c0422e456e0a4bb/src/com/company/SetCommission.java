package com.company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SetCommission {
    public JPanel panel;
    private JTextArea textArea1;
    private JButton addCommissionButton;
    private JTextField commissionTextField;
    private JButton deleteButton;
    private JButton cancelButton;

    public SetCommission(JFrame frame) {
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.officeMenu);
                frame.setVisible(true);
            }
        });
    }
}
