package com.company.blank;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReturnBlank {
    public JPanel panel;
    private JButton closeButton;
    private JButton button1;
    private JComboBox blankType;
    private JTextField textField1;

    public ReturnBlank(JFrame frame) {
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewBlanks);
                frame.setVisible(true);
            }
        });
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewBlanks);
                frame.setVisible(true);
            }
        });
    }
}
