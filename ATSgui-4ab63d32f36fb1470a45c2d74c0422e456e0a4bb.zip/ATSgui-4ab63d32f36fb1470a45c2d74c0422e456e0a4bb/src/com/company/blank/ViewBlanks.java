package com.company.blank;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewBlanks {
    private JButton mainMenuButton;
    private JButton recordSaleButton;
    private JButton returnBlankButton;
    public JPanel panel;
    private JTable table1;
    private JButton stolenLostBlankButton;

    public ViewBlanks(JFrame frame) {
        mainMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.mainMenu);
                frame.setVisible(true);
            }
        });
        recordSaleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.recordSale);
                frame.setVisible(true);
            }
        });
        returnBlankButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.returnBlank);
                frame.setVisible(true);
            }
        });

        stolenLostBlankButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.lostStolenBlank);
                frame.setVisible(true);
            }
        });
    }
}
