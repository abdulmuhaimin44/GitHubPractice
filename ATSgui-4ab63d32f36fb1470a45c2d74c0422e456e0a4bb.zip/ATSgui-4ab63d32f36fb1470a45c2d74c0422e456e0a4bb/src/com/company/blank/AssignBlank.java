package com.company.blank;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AssignBlank {
    private JComboBox comboBox1;
    private JComboBox comboBox2;
    private JButton saveButton;
    private JButton closeButton;
    public JPanel panel;

    public AssignBlank(JFrame frame) {
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.officeMenu);
                frame.setVisible(true);
            }
        });
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.officeMenu);
                frame.setVisible(true);
            }
        });
    }
}
