package com.company.blank;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RecordSale {
    public JPanel panel;
    private JButton button1;
    private JButton closeButton;
    private JComboBox blankType;
    private JTextField textField1;
    private JTextArea textArea1;
    private JTextField textField2;
    private JComboBox comboBox1;
    private JComboBox comboBox2;
    private JTextField textField3;
    private JTextField textField4;

    public RecordSale(JFrame frame) {
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewBlanks);
                frame.setVisible(true);
            }
        });
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewBlanks);
                frame.setVisible(true);
            }
        });
    }
}
