package com.company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OfficeMenu {
    private JButton logoutButton;
    private JButton recordSaleButton;
    private JButton showIndividualReportButton;
    private JButton viewBlanksButton;
    private JButton viewCustomersButton;
    public JPanel panel;
    private JButton assignBlankButton;
    private JButton setCommissionRatesButton;
    private JButton showReportsButton;

    public OfficeMenu(JFrame frame) {
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.login);
                frame.setVisible(true);
            }
        });
        recordSaleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.recordSale);
                frame.setVisible(true);
            }
        });
        viewBlanksButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewBlanks);
                frame.setVisible(true);
            }
        });
        viewCustomersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.viewCustomers);
                frame.setVisible(true);
            }
        });
        assignBlankButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.assignBlank);
                frame.setVisible(true);
            }
        });
        setCommissionRatesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.setCommission);
                frame.setVisible(true);
            }
        });
        showReportsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.showReports);
                frame.setVisible(true);
            }
        });
    }
}
