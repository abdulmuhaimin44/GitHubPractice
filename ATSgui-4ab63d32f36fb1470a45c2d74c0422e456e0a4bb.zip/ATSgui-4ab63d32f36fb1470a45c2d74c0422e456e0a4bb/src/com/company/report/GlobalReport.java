package com.company.report;

public class GlobalReport {
}
