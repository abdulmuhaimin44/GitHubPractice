package com.company.report;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ShowReports {
    private JButton individualReportButton;
    private JButton globalReportButton;
    private JButton turnoverReportButton;
    private JButton closeButton;
    public JPanel panel;

    public ShowReports(JFrame frame) {
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setContentPane(Main.officeMenu);
                frame.setVisible(true);
            }
        });
    }
}
